import Navbar from "../components/navbar/Navbar"
import Footer from "../components/footer/Footer"

function TopRatedMovie() {
    return (
      <>
        {/* <Navbar /> */}
        <h2>Top Rated</h2>
        {/* <Footer /> */}
      </>
    );
  }
  
  export default TopRatedMovie;