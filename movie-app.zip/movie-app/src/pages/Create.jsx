import Navbar from "../components/navbar/Navbar";
import Footer from "../components/footer/Footer";

function CreateMovie(){
    return(
        <>
        {/* <Navbar /> */}
            <h2>Create Movie</h2>
        {/* <Footer /> */}
        </>
    )
}

export default CreateMovie;