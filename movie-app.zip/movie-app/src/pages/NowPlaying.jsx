import Navbar from "../components/navbar/Navbar";
import Footer from "../components/footer/Footer";

function NowPlaying(){
    return(
        <>
        {/* <Navbar /> */}
            <h2>Now Playing</h2>
        {/* <Footer /> */}
        </>
    )
}

export default NowPlaying;